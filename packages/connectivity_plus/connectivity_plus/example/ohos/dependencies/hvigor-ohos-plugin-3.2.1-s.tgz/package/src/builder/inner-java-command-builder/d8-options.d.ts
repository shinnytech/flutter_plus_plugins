import { JavaCommandBuilder } from '../java-command-builder.js';
export declare class D8Options extends JavaCommandBuilder {
    constructor();
    addInputFiles(inputFile: string): D8Options;
    addInputDir(inputDir: string): D8Options;
    addOutputDir(outputDir: string): D8Options;
    addLib(lib: string): D8Options;
    addMinApi(api: string): D8Options;
}
