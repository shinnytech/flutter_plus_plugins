import { DefaultTask, HvigorNode } from '@ohos/hvigor';
import { TaskService } from '../service/task-service.js';
import { SdkInfo } from '../../sdk/sdk-info';
/**
 * module级别的clean
 *
 * @since 2022/1/10
 */
export declare class Clean extends DefaultTask {
    private readonly _taskService;
    private _logger;
    constructor(node: HvigorNode, taskService: TaskService);
    projectNativeClean: (sdkInfo: SdkInfo | undefined) => void;
    getArchDirectories: (directoryPath: string) => string[];
    registryAction: () => Function;
    clean: () => void;
    rmdirSyncWithBuildDir: (buildDir: string) => boolean;
    rmdirSync: (dirPath: string, hasError: boolean) => boolean;
}
