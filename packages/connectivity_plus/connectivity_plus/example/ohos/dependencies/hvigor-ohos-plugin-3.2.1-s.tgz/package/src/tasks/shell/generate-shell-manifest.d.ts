import { XMLNode } from '../../utils/xml-utils';
import { TargetTaskService } from '../service/target-task-service.js';
import { OhosHapTask } from '../task/ohos-hap-task';
/**
 * 生成打壳需要的文件
 *
 * @since 2022/2/18
 */
export declare class GenerateShellManifest extends OhosHapTask {
    private _moduleModel;
    private _moduleTargetRes;
    private _configObj;
    private configRule;
    private _log;
    private _builder;
    private _moduleType;
    constructor(taskService: TargetTaskService);
    initTaskDepends(): void;
    taskShouldDo(): boolean;
    protected doTaskAction(): void;
    protected generateManifest(): void;
    protected addConfig2Node(parent: XMLNode): void;
    /**
     * 新版本的生成network-security-config.xml入口
     *
     * @private
     */
    private generateNetworkConfig;
    private addIconLabel;
    private addDeviceConfig2Node;
    private addModule2Node;
    private addAbilities2Node;
    private handleDataAbility;
    private static handlePageAbility;
    private addSkills2Node;
    private addDefPermissionInfo2Node;
    private addReqPermissionsInfo2Node;
    private addDefPermissionGroupsInfo2Node;
    private addNetwork2Node;
    private addCustomizeData2Node;
    private handleInputMethod;
    private handleAccessibilityConfig;
}
