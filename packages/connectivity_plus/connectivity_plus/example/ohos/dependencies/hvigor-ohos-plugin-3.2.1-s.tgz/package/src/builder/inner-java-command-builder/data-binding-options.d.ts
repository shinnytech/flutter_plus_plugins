import { JavaCommandBuilder } from '../java-command-builder.js';
export declare class DataBindingOptions extends JavaCommandBuilder {
    constructor();
    setOutputDir(outputDir: string): DataBindingOptions;
    setModulePackageName(packageName: string): DataBindingOptions;
    addInputDir(inputDir: string): DataBindingOptions;
}
