import { TargetTaskService } from '../service/target-task-service.js';
import { OhosShellHapTask } from './ohos-shell-hap-task.js';
/**
 * aapt编译资源shell
 *
 * @since 2022/02/19
 */
export declare class GenerateResourcesShell extends OhosShellHapTask {
    private _log;
    constructor(taskService: TargetTaskService);
    initTaskDepends(): void;
    taskShouldDo(): boolean;
    protected beforeTask(): void;
    protected doTaskAction(): Promise<void>;
    private aaptCompile;
    private aaptLink;
}
