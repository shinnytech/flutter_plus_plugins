import { NativeTarget } from './native-codemodel-target.js';
import { NativeLibraryModel } from './native-library-model.js';
export declare class GenerateNativeLibrary {
    private readonly library;
    constructor(cmakeExe: string, outputDir: string, abi: string, nativeTarget: NativeTarget, target: string);
    getLibrary(): NativeLibraryModel;
    createBuildCommand(cmakeExe: string, outputDir: string): string[];
    private findFolders;
    private findFiles;
    private findOutputs;
    private findRuntimeFiles;
}
