import { TargetTaskService } from '../service/target-task-service.js';
import { OhosShellHapTask } from './ohos-shell-hap-task.js';
/**
 * compileJavaWithJavac Task
 *
 * @since 2022/1/10
 */
export declare class CompileJavaWithJavac extends OhosShellHapTask {
    private readonly _log;
    constructor(taskService: TargetTaskService);
    initTaskDepends(): void;
    taskShouldDo(): boolean;
    protected beforeTask(): void;
    protected doTaskAction(): Promise<void>;
    private compileJavaFiles;
}
