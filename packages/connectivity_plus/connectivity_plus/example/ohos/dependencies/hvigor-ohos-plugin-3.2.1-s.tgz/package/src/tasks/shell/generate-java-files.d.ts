import { TargetTaskService } from '../service/target-task-service.js';
import { OhosHapTask } from '../task/ohos-hap-task.js';
/**
 * 根据config.json生成java文件
 */
export declare class GenerateJavaFiles extends OhosHapTask {
    constructor(taskService: TargetTaskService);
    initTaskDepends(): void;
    taskShouldDo(): boolean;
    protected beforeTask(): void;
    protected doTaskAction(): void;
    /**
     * output a file whose context contains all java files' path
     * file path: [outputDir]/javaList
     *
     * @param {string} outputDir
     * @param {string[]} javaFiles
     * @private
     */
    private outputJavaList;
}
