import { TaskDetails } from '@ohos/hvigor';
import { TargetTaskService } from '../service/target-task-service.js';
import { OhosHarTask } from '../task/ohos-har-task.js';
export interface HarBuildProfileData {
    BUNDLE_NAME: string;
    VERSION_CODE: number;
    VERSION_NAME: string;
    HAR_VERSION: string;
    BUILD_MODE_NAME: string;
    DEBUG: boolean;
}
/**
 * har自定义参数buildProfile基础类
 */
export declare abstract class HarBaseBuildProfileTask extends OhosHarTask {
    protected readonly _taskService: TargetTaskService;
    private _log;
    protected harBuildProfileData: HarBuildProfileData | undefined;
    protected constructor(taskService: TargetTaskService, taskDetails: TaskDetails);
    protected initDefaultData(): void;
    protected writeProfileToDir(): void;
    initTaskDepends(): void;
    protected doTaskAction(): void;
}
