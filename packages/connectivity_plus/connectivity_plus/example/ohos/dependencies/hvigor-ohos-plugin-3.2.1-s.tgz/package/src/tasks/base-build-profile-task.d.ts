import { TaskDetails } from '@ohos/hvigor';
import { TargetTaskService } from './service/target-task-service.js';
import { OhosHapTask } from './task/ohos-hap-task.js';
export interface BuildProfileData {
    BUNDLE_NAME: string;
    BUNDLE_TYPE: string;
    TARGET_NAME: string;
    PRODUCT_NAME: string;
    BUILD_MODE_NAME: string;
    DEBUG: boolean;
    VERSION_CODE: number;
    VERSION_NAME: string;
}
/**
 *
 * hap/hsp自定义参数buildProfile基础类
 */
export declare class BaseBuildProfileTask extends OhosHapTask {
    protected readonly _taskService: TargetTaskService;
    private _log;
    protected buildProfileData: BuildProfileData | undefined;
    protected constructor(taskService: TargetTaskService, taskDetails: TaskDetails);
    /**
     * @protected
     */
    protected initDefaultData(): void;
    protected writeProfileToDir(): void;
    initTaskDepends(): void;
    protected doTaskAction(): void;
}
