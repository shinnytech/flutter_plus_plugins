import { FileSet, TaskInputValue } from '@ohos/hvigor';
import { TargetTaskService } from '../service/target-task-service.js';
import { HarBaseBuildProfileTask } from './har-base-build-profile-task.js';
export declare class HarBuildProfileTask extends HarBaseBuildProfileTask {
    constructor(taskService: TargetTaskService);
    /**
     * 添加增量判断，当app.json5或工程级的build-profile.json5文件发生变化时重新生成buildProfile.ets文件
     */
    declareInputFiles(): FileSet;
    declareOutputFiles(): FileSet;
    declareInputs(): Map<string, TaskInputValue>;
    protected doTaskAction(): void;
}
