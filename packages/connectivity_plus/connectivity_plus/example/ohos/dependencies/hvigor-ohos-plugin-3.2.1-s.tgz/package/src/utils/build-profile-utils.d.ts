import { ModuleTargetData } from '../tasks/data/hap-task-target-data.js';
import { OhosLogger } from './log/ohos-logger.js';
/**
 * 生成buildProfile.ets文件
 *
 * @param buildProfileData
 * @param targetData
 * @param _log
 */
export declare const normalizedFileData: (buildProfileData: object, targetData: ModuleTargetData, _log: OhosLogger) => string;
