import { TargetTaskService } from './service/target-task-service.js';
import { AbstractBuildNative } from './abstract-build-native.js';
/**
 * ohos native代码编译任务
 *
 * @since 2021/1/21
 */
export declare class BuildNativeWithCmake extends AbstractBuildNative {
    private _log;
    private readonly _moduleDir;
    constructor(taskService: TargetTaskService);
    initTaskDepends(): void;
    taskShouldDo(): boolean;
    protected doTaskAction(): Promise<void>;
    buildCommand(abiFilter: string): string[];
}
