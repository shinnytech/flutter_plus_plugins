/**
 * 记录打点数据：taskTime
 *
 * @param taskName
 * @param time
 */
export declare function recordTraceData(taskName: string, time: number): void;
