/**
 * 对pretty-hrtime格式化后的时间做进一步处理
 *
 * @param source pretty-hrtime格式化后的时间
 */
export declare function splitTime(source: string): string;
/**
 * 对构建显示时间进行格式化处理
 *
 * @param time 待处理的时间
 */
export declare function formatTime(time: [number, number]): string;
/**
 * 判断日志是否是显示时间的Hvigor日志
 *
 * @param log 待判断的日志内容
 */
export declare function isHvigorLogWithTime(log: string): boolean;
