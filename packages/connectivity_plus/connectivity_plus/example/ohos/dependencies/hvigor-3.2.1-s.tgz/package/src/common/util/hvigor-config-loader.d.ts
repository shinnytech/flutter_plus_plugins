import { HvigorConfig } from '../../base/util/hvigor-config-reader.js';
export declare class HvigorConfigLoader {
    private readonly hvigorConfig;
    /**
     * 初始化读取两个配置文件 userhome下的和项目目录下的
     *
     */
    constructor();
    getHvigorConfig(): HvigorConfig | undefined;
    getPropertiesConfigValue<T>(key: string): T | undefined;
    static getInstance(): HvigorConfigLoader;
}
