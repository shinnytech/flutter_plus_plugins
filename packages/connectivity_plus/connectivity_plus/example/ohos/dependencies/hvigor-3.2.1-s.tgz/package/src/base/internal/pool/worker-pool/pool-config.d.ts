/**
 * 池配置
 *
 * @since 2022/8/12
 */
export type PoolConfig = {
    maxPoolNum?: number;
    minPoolNum?: number;
    recycleInterval?: number;
    maxIdleTime?: number;
};
