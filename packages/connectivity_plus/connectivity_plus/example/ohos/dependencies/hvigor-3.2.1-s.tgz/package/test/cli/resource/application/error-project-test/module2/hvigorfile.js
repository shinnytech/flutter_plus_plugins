// Script for compiling build behavior. It is built in the build plug-in and cannot be modified currently.
let project = require('@ohos/hvigor')(__filename);

project.task(() => {
  console.log('This is a clean task');
}, 'clean1').dependsOn('clean2');

project.task(() => {
  console.log('This is a clean task');
}, 'clean2').dependsOn('clean3');

project.task(() => {
  console.log('This is a clean task');
}, 'clean3').dependsOn('clean1');