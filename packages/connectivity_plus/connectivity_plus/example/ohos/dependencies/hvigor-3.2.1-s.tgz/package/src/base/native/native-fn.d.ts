export declare const loop: (pred: Function) => void;
