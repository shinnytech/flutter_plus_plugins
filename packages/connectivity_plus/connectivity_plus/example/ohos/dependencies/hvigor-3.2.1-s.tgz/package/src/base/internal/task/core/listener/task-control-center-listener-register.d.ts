import { TaskControlCenter } from '../task-control-center.js';
/**
 * 根据不同的Task Event注册不同的事件监听
 *
 * @since 2022/9/1
 */
export declare class TaskControlCenterListenerRegister {
    private readonly taskControlCenter;
    constructor(taskControlCenter: TaskControlCenter);
    /**
     * 注册所有当前任务需要实现的监听
     */
    registryAllDefault(): void;
    private registry;
}
export declare const taskControlCenterListenerRegister: TaskControlCenterListenerRegister;
