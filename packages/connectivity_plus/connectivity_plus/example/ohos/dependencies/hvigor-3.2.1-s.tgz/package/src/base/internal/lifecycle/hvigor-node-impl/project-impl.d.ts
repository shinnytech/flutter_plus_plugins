import { Module, Project } from '../../../external/core/hvigor-node.js';
import { DefaultNodeImpl } from './default-node-impl.js';
/**
 * hvigor工程的基础root module
 *
 * @since 2021/12/27
 */
export declare class ProjectImpl extends DefaultNodeImpl implements Project {
    classKind: string;
    private readonly _subProjects;
    constructor(projectName: string, moduleDir: string);
    findModuleByName(moduleName: string): Module | undefined;
    getProject(): Project;
    getSubModules(): Map<string, Module>;
    addSubModule(module: Module): void;
    getAllSubModules(): Module[];
}
