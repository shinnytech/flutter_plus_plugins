import { Task } from '../../../external/task/task.js';
import { TaskContainer } from '../interface/task-container-interface.js';
import { TaskDetails } from '../interface/task-details-interface.js';
export type TaskCreation = {
    provider: () => Task;
    depends: string[];
    details: TaskDetails;
};
export declare class LazyTaskContainer implements TaskContainer {
    private readonly _moduleName;
    private _tasks;
    private _lazyTasks;
    constructor(moduleName: string);
    registerTask(creation: TaskCreation): void;
    addTask(task: Task): void;
    deleteTask(taskName: string): boolean;
    hasTask(taskName: string): boolean;
    getLazyTask(task: string): TaskCreation | undefined;
    getTask(task: string): Task | undefined;
    /**
     * 获取所有任务
     * 仅返回已初始化的task
     */
    getAllTasks(): Task[];
    getTaskPaths(): string[];
    findTask(taskName: string): Task | undefined;
    getTaskDepends(taskPath: string): string[];
    clearTasks(): void;
    private initializeLazyTask;
    private mergeDepends;
}
