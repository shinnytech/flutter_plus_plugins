export declare function initProjectWorkSpace(): string;
