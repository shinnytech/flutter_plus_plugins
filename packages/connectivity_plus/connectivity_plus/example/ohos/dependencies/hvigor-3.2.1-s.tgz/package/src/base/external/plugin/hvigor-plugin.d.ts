export interface HvigorPlugin {
    pluginId: string;
    apply: (pluginContext: HvigorPluginContext) => void;
}
export interface HvigorPluginContext {
    registerTask: (task: HvigorPluginTask) => void;
}
export interface HvigorPluginTask {
    name: string;
    run: (taskContext: HvigorTaskContext) => void;
    dependencies?: string[];
    postDependencies?: string[];
}
export interface HvigorTaskContext {
    moduleName: string;
    modulePath: string;
}
