import { WorkerPoolDelegator } from '../../internal/pool/worker-pool/worker-delegator.js';
import { TaskExecuteStatus } from '../../internal/task/core/task-execute-status.js';
import { TaskDetails } from '../../internal/task/interface/task-details-interface.js';
import { HvigorLogger } from '../../log/hvigor-log.js';
import { DurationEvent } from '../../metrics/event/duration-event.js';
import { HvigorNode } from '../core/hvigor-node.js';
import { Task } from './task.js';
/**
 * hvigor task的核心类，包含了基础的成员变量和默认的方法实现
 *
 * @since 2022/4/22
 */
export declare class CoreTaskImpl extends Task {
    protected taskLog: HvigorLogger;
    protected node: HvigorNode;
    protected name: string;
    protected path: string;
    protected dependsTask: string[];
    protected fn: Function;
    protected isEnabled: boolean;
    protected group: string;
    protected description: string;
    private subDurationEventMap;
    private readonly workerDelegator;
    taskExecutedStatus: TaskExecuteStatus;
    durationEvent: DurationEvent;
    constructor(node: HvigorNode, taskDetails: TaskDetails);
    getWorkerPool(): WorkerPoolDelegator;
    execute(): Promise<void>;
    taskShouldDo(): boolean;
    setDependsOn(...taskNames: string[]): Task;
    getDependsOn(): string[];
    addDependsOn(taskName: string): Task;
    dependsOn(task: string | Task, node?: string | HvigorNode): Task;
    /**
     * 添加模块间任务依赖时，根据对应的模块名找对应依赖的模块,当前顺序为先模块后工程
     * 由于存在模块名和工程名一样的场景,因此增加一个默认":"时代表project
     *
     * @param {string} nodeName
     * @return {Module | Project}
     * @private
     */
    private findTargetNode;
    private isProject;
    getAction(): Function;
    getNode(): HvigorNode;
    getName(): string;
    getPath(): string;
    getTaskLog(): HvigorLogger;
    getEnabled(): boolean;
    setEnabled(enabled: boolean): Task;
    setDescription(description: string): Task;
    getDescription(): string | undefined;
    getGroup(): string;
    setGroup(group: string): Task;
    doNotTrackState(reason: string): void;
    /**
     * 添加任务子矩阵
     *
     * @param workId
     */
    addSubDurationEvent(workId: string): DurationEvent;
    /**
     * 获取任务子矩阵
     *
     * @param workId
     */
    getSubDurationEvent(workId: string): DurationEvent | undefined;
    /**
     * 根据hvigorNode以及task name来获取task的path
     *
     * @param {DefaultNodeImpl} hvigorNode
     * @param {string} taskName
     * @returns {string}
     */
    private static createTaskPath;
}
