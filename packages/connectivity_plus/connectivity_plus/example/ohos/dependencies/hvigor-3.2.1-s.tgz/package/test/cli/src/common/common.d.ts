export declare function writeFileContent(filePath: string, content: string): void;
export declare function addModule(projectRootPath: string, moduleName: string): void;
