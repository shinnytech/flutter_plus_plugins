import { HvigorNode } from '../../external/core/hvigor-node.js';
/**
 * 执行每个module中注册的sync类型的任务，将对应的数据模型注册到registry中
 *
 * @param {HvigorNode} hvigorNode
 */
export declare function findSyncTaskPathsForNode(hvigorNode: HvigorNode): string[];
/**
 * 打印sync的信息到输出流中
 */
export declare function outputPluginSyncInfo(): void;
