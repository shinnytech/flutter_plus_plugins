import { HvigorLogger } from '../../base/log/hvigor-log.js';
export declare class PathUtil {
    private static hasLogged;
    /**
     * 获取.hvigor的根目录，就是编译时产生的.hvigor文件夹，不是userHome下的
     * 例如D:\test\ToDoListArkTS\.hvigor
     * 会先从项目的配置文件中获取，不存在则获取userHome目录下的配置文件，都不存在返回项目下的
     */
    static getHvigorCacheDir(logger?: HvigorLogger): string;
}
