export declare const PNPM_VERSION = "7.30.0";
/**
 * 检查npmrc是否配置
 *
 */
export declare function checkNpmConifg(): void;
/**
 * 处理环境变量
 */
export declare function environmentHandler(): void;
/**
 * 验证USER_HOME/.hvigor/wrapper/tools目录下pnpm是否可用
 *
 * @returns {boolean} true/false
 */
export declare function isPnpmInstalled(): boolean;
/**
 * 执行pnpm的安装
 */
export declare function executeInstallPnpm(): void;
