import { HvigorNode } from '../../external/core/hvigor-node.js';
/**
 * Config整个hvigor的项目，进行数据绑定
 *
 */
export declare function configuration(): Promise<HvigorNode>;
